# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2019, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# Load Data from CSV files

library(readr)
library(scales)

readDataset <- function(fileName) {read.csv(file.path(fileName)) }

customer <- readDataset("customer.csv")
events <- readDataset("event.csv")
event_types <- readDataset("event_type.csv")
news <- read.delim(file.path("news.csv"), sep = "|")[2:6,]

clients <- list(
  list(name="Paige Carson", image="1F.jpg", trigger="Charitable Donation (Detected)",netWorth="$3.80 Million",split = c(2.1,0.9,0.8)),
  list(name="Jane Wilson", image="8F.jpg", trigger="Relocation (Predicted)", netWorth="$3.62 Million", split = c(1.2,1.2,1.22)),
  list(name="Alex Anderson", image="2M.jpg", trigger="High Client Attrition (Predicted)",netWorth="$3.22 Million", split = c(0.5,1.7,1.02)),
  list(name="Ian Gray", image="3M.jpg", trigger="Retirement (Detected)",netWorth="$5.25 Million", split = c(2.1,2.2,0.95)),
  list(name="Robert Taylor", image="4M.jpg", trigger="Birth of a Child (Detected)",netWorth="$570,000", split = c(0.1, 0.3,0.175))
)
clientIds <- c(1039, 1023, 1040, 1041, 1011)
names(clients) <- clientIds

for(id in clientIds) {
  clients[[toString(id)]]$income <- dollar(customer[customer$CUSTOMER_ID == id,][[1,'ANNUAL_INCOME']])
}

