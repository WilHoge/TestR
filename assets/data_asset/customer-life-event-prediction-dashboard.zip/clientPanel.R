# Sample Materials, provided under license.
# Licensed Materials - Property of IBM
# © Copyright IBM Corp. 2019, 2020. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

# Load shap JavaScript
#shapjs <- content(GET("https://github.com/slundberg/shap/raw/0849aa20551cf9825f9e294fcc29d7fbe7b9f932/shap/plots/resources/bundle.js"))

clientPanel <- function() {
  
  tabPanel(
    "Client View",
    value = "clientPanel",
    
    panel(
      br(),br(),
      fluidRow(
        column(3, class = "pull-left",
               div(id = "customerImage"),
               h2(class = "text-center" ,textOutput("customerName"))),
        column(3, 
               h4("Personal Information", class="text-center"),
               hr(),
               uiOutput("customerInfo")
        ),
        column(3,
          h4(class = "text-center", "Total Net Worth",textOutput("customerNetworth")),
          plotOutput("customerWorthPie", width = "100%", height = "200px")
        ),
        column(3, 
               h4("Financial Profile", class="text-center"),
               hr(),
               uiOutput("customerFinancesInfo")
        )
      ),
      br()
    ),
    
    fluidRow(
    column(7,
      panel(
        h2("Life Event"),
        br(),
        #DTOutput("customerEventsTable")
        tableOutput("customerLifeEventsTable")
      )
    ),
    column(5, 
      panel(
        h2("Opportunities"),
        uiOutput("customerOpportunities")
      )
    )),
    
    panel(
      h2("Life Event Prediction "),
      br(),
      
      # Load shap JS
#      tags$script(HTML(shapjs)),
      
      # Listen for responseInserted messages
#      tags$script("
#        Shiny.addCustomMessageHandler('responseInserted', function(elem) {
#          var checkExist = setInterval(function() {
#             if ($('#'+elem.id).length) {
#                if (window.SHAP)
#                  SHAP.ReactDom.render(
#                    SHAP.React.createElement(SHAP.AdditiveForceVisualizer, elem.data),
#                    document.getElementById(elem.id)
#                  );
#                clearInterval(checkExist);
#             }
#          }, 100); // check every 100ms
          
#        });
#      "),
      
      tags$div(
        id = "authPanel",
        column(4,
          panel(
            h4("Connect to Cloud Pak for Data API"),
            textInput("hostname", "CPD Hostname"),
            textInput("username", "CPD Username"),
            passwordInput("password", "CPD Password"),
            actionButton("authBtn", "Authenticate API", class = "btn-primary btn-lg btn-block", style = "max-width:300px", disabled = TRUE),
            tags$head(tags$style("#authError{color:red;}")),
            verbatimTextOutput("authError")
          ),
          style = "max-width:360px;"
        )
      ),
      hidden(
        tags$div(
          id = "deploymentPanel",
          column(4,
             panel(
               tags$h4("Model Scoring Pipeline Deployment"),
               pickerInput(
                 inputId = 'deploymentSelector',
                 label = 'Deployment:',
                 choices = list(),
                 options = pickerOptions(width = "auto", style = "btn-primary")
               ),
               tags$p(
                 tags$strong("Space Name: "),
                 textOutput(outputId = "space_name", inline = TRUE)
               ),
               tags$p(
                 tags$strong("GUID: "),
                 textOutput(outputId = "deployment_guid", inline = TRUE)
               ),
               tags$p(
                 tags$strong("Tags: "),
                 textOutput(outputId = "deployment_tags", inline = TRUE),
                 style = "word-wrap: break-word"
               ),
               tags$p(
                 tags$strong("Scoring Endpoint: "),
                 textOutput(outputId = "scoring_url", inline = TRUE),
                 style = "word-wrap: break-word"
        #       ),
        #       tags$p(
        #         tags$strong("Engine: "),
        #         textOutput(outputId = "runtime", inline = TRUE)
        #       ),
        #       tags$p(
        #         tags$strong("Project Release: "),
        #         textOutput(outputId = "release_name", inline = TRUE)
               )
             )
          ),
          tags$div(id = "scoreBtnSection",
            column(4,
              br(),br(),
              actionButton(
                 "scoreBtn",
                 "Predict Life Events",
                 class = "btn-primary btn-lg btn-block",
                 disabled = TRUE
               ),
              br(),
              h4("Input JSON:"),
              verbatimTextOutput("pipelineInput"),
              br(),
              tags$head(tags$style("#scoringError{color:red;}")),
              verbatimTextOutput("scoringError"))
          ),
          column(8,
             hidden(
               tags$div(id = "scoringResponse")
             )
          )
        )
      )
    )
  )
}


# Reactive server variables store (pervades across all sessions)
serverVariables = reactiveValues(deployments = list(),token = '')


if(nchar(Sys.getenv('CP4D_HOSTNAME')) > 0 && nchar(Sys.getenv('CP4D_USERNAME')) > 0 && nchar(Sys.getenv('CP4D_PASSWORD')) > 0) {
  tryCatch({
    deploymentsResp = collectDeployments(Sys.getenv('CP4D_HOSTNAME'), Sys.getenv('CP4D_USERNAME'), Sys.getenv('CP4D_PASSWORD'), "lfe_scoring_pipeline_function_deployment_tag")
    serverVariables$deployments <- deploymentsResp$deployments
    serverVariables$token = deploymentsResp$token
  }, warning = function(w) {
    print(w$message)
  }, error = function(e) {
    print(e$message)
  })
}



clientServer <- function(input, output, session, sessionVars) {
  
  observe({

    client <- clients[[toString(sessionVars$selectedClientId)]]

    # Update client name & image
    output$customerName <- renderText(client$name)
    output$customerNetworth <- renderText(client$netWorth)
    
    removeUI(selector = "#customerImage > *")
    insertUI(
      selector = "#customerImage",
      where = "beforeEnd",
      ui = img(class="img-circle img-responsive", src = paste0("profiles/",client$image), style = "display: block;margin-left: auto;margin-right: auto;", width=150, height=150)
    )
    
    # Load customer data for customer sessionVars$selectedClientId
    selection <- customer[customer$CUSTOMER_ID == sessionVars$selectedClientId,][1,]

    output$customerInfo <- renderUI({
      infoDets <- selection[,c("AGE_RANGE", "MARITAL_STATUS", "FAMILY_SIZE", "PROFESSION", "EDUCATION_LEVEL")]
      infoDets[["FAMILY_SIZE"]] <- as.integer(infoDets[["FAMILY_SIZE"]])
      infoDets[["ADDRESS"]] <- paste(selection[,"ADDRESS_HOME_CITY"], selection[,"ADDRESS_HOME_STATE"], sep = ', ')
        tags$ul( class = 'list-unstyled',
          tags$li(
            tags$strong('Age: '), tags$span(class = "pull-right", infoDets[["AGE_RANGE"]], ' years old')
          ),
          tags$li(
            tags$strong('Marital Status: '),tags$span(class = "pull-right", infoDets[["MARITAL_STATUS"]])
          ),
          tags$li(
            tags$strong('Address: '), tags$span(class = "pull-right", infoDets[["ADDRESS"]])
          ),
          tags$li(
            tags$strong('Profession: '), tags$span(class = "pull-right",infoDets[["PROFESSION"]])
          ),
          tags$li(
            tags$strong('Level of Education: '), tags$span(class = "pull-right", infoDets[["EDUCATION_LEVEL"]])
          )
        )
    })
    output$customerFinancesInfo <- renderUI({
      customerfinDets <- selection[,c("ANNUAL_INCOME", "HOME_OWNER_INDICATOR", "MONTHLY_HOUSING_COST", "CREDIT_SCORE", "CREDIT_AUTHORITY_LEVEL")]
      customerfinDets[["ANNUAL_INCOME"]] <- dollar(customerfinDets[["ANNUAL_INCOME"]])
      customerfinDets[["MONTHLY_HOUSING_COST"]] <- dollar(customerfinDets[["MONTHLY_HOUSING_COST"]])
      tags$ul( class = 'list-unstyled',
               tags$li(
                 tags$strong('Annual income: '), tags$span(class="pull-right", customerfinDets[["ANNUAL_INCOME"]])
               ),
               tags$li(
                 tags$strong('Home Owner: '), tags$span(class="pull-right", if(customerfinDets[["HOME_OWNER_INDICATOR"]] == TRUE) { 'Yes'} else { 'No'})
               ),
               tags$li(
                 tags$strong('Monthly Housing: '), tags$span(class="pull-right", customerfinDets[["MONTHLY_HOUSING_COST"]])
               ),
               tags$li(
                 tags$strong('Credit Score: '), tags$span(class="pull-right", round(customerfinDets[["CREDIT_SCORE"]]))
               ),
               tags$li(
                 tags$strong('Credit Authority Level: '), tags$span(class="pull-right", customerfinDets[["CREDIT_AUTHORITY_LEVEL"]])
               )
        
      )
    })
    # output$customerEventsTable <- renderDT(customerEvents[,c("EVENT_DATE", "NAME", "CATEGORY")], 
    #                                        rownames = FALSE, options = list(order = list(list(0, 'desc'))), style = 'bootstrap')
    
    
    

    # Load customer and event data for customer sessionVars$selectedClientId
    selection <- customer[customer$CUSTOMER_ID == sessionVars$selectedClientId,][1,]
    customerEvents <- events[events$CUSTOMER_ID == sessionVars$selectedClientId,]
    customerEvents <- merge(event_types, customerEvents, by="EVENT_TYPE_ID")
    customerEvents <- customerEvents[,c("CUSTOMER_ID", "EVENT_DATE", "NAME", "CATEGORY")]
    
    customerLifeEvents <- customerEvents[customerEvents$CATEGORY == "Life",]
    customerLifeEvents <- customerLifeEvents[, c("EVENT_DATE", "NAME")]
    names(customerLifeEvents) <- c("DATE", "EVENT")
    customerLifeEvents$DATE <- format(customerLifeEvents$DATE , format = "%B %d, %Y")
    customerLifeEvents <- customerLifeEvents[order(customerLifeEvents$DATE, decreasing = TRUE),]
    output$customerLifeEventsTable <- renderTable(customerLifeEvents, hover = TRUE, bordered = TRUE, spacing = "m", width = "100%", align = "l")
    
    output$customerOpportunities <- renderUI({
      selectionCus <- customer[customer$CUSTOMER_ID == sessionVars$selectedClientId,]
      selectionCus <- selectionCus %>% count(PURSUIT)
      lapply(1:dim(selectionCus)[1], function(index){
        h4(class="well well-sm text-center",selectionCus$PURSUIT[index])
      })
    })
    
    # Generate donut pie chart about worth net
    mycols <- c("#CD534CFF","#0073C2FF", "#EFC000FF")
    customerWorth <- data.frame(
      WORTH_TYPE = c("External:", "Internal:", "Manual:"),
      VALUE = client$split,
      PROP = c(89.22, 0.98, 9.8)
    )
    
    customerLabels <- lapply(1:dim(customerWorth)[1], function(index){
      paste0(customerWorth$WORTH_TYPE[index]," ", customerWorth$VALUE[index],"M")
    })
    
    customerWorthPlot <- ggplot(customerWorth, aes(x = 2, y = VALUE, fill = WORTH_TYPE)) +
      geom_bar(stat = "identity", color = "white") +
      coord_polar(theta = "y", start = 0)+
      scale_fill_manual(values = mycols) +
      theme_void()+
      xlim(0.5, 2.5)+
      scale_fill_discrete(name = "Net Worth", labels = customerLabels)+ 
      theme(legend.title = element_text(size=18, face="bold"))+
      theme(legend.text = element_text(size=20))
    
    
    output$customerWorthPie <- renderPlot(customerWorthPlot, width="auto", height="auto")
    
    # Generate pie chart of event types distribution
    # customerEventCounts <- data.frame(table(customerEvents$NAME)) %>%
    #   mutate(
    #     percentage = Freq / sum(Freq),
    #     hover_text = paste0(Var1, ": ", round(100 * percentage, 1), "%")
    #   )
    # count_plot <- ggplot(customerEventCounts, aes(y = Freq, fill = Var1)) +
    #   geom_bar_interactive(
    #     aes(x = 1, tooltip = hover_text),
    #     stat = "identity",
    #     show.legend = TRUE
    #   ) + 
    #   coord_polar(theta = "y") +
    #   theme_void() +
    #   theme(legend.title=element_text(size=16), 
    #         legend.text=element_text(size=12))
    # count_plot <- count_plot + guides(fill=guide_legend(title="Event Types"))
    # output$customerEventsPlot <- renderggiraph(ggiraph(ggobj = count_plot, width_svg=6, height_svg=4))

    # Reset scoring
    removeUI(selector = "#scoringResponse > *", multiple = TRUE)
    shinyjs::hide(id = "scoringResponse")
    shinyjs::show(id = "scoreBtnSection")
    output$scoringError <- renderText('')
    sessionVars$pipelineInput <- list(cust_id = sessionVars$selectedClientId, values = '2018-09-30')
    output$pipelineInput <- renderText(toJSON(sessionVars$pipelineInput, indent = 2))
  })
  
  # Set default hostname for CP4D API
  observeEvent(session$clientData$url_hostname, {
    updateTextInput(session, "hostname", value = session$clientData$url_hostname)
  })
  
  # Enable buttons when inputs are provided
  observe({
    toggleState("authBtn", nchar(input$hostname) > 0 && nchar(input$username) > 0 && nchar(input$password) > 0)
    toggleState("scoreBtn", nchar(input$endpoint) > 0 && nchar(input$token) > 0 && length(input$allCustomers_rows_selected) > 0)
  })
  
  # Handle CP4D API authentication button
  observeEvent(input$authBtn, {
    shinyjs::disable("authBtn")
    
    tryCatch({
      deploymentsResp = collectDeployments(input$hostname, input$username, input$password, "lfe_scoring_pipeline_function_deployment_tag")
      serverVariables$deployments <- deploymentsResp$deployments
      serverVariables$token = deploymentsResp$token
      
    }, warning = function(w) {
      output$authError <- renderText(w$message)
    }, error = function(e) {
      output$authError <- renderText(e$message)
    })
    shinyjs::enable("authBtn")
  })
  
  observe({
    if(length(serverVariables$deployments) > 0) {
      updateSelectInput(session, "deploymentSelector", choices = names(serverVariables$deployments))
      shinyjs::hide(id = "authPanel")
      shinyjs::show(id = "deploymentPanel")
    }
  })
  
  # Handle model deployment dropdown switching
  observeEvent(input$deploymentSelector, {
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    output$deployment_guid <- renderText(selectedDeployment$guid)
    output$space_name <- renderText(selectedDeployment$space_name)
    output$deployment_tags <- renderText(selectedDeployment$tags)
    output$scoring_url <- renderText(selectedDeployment$scoring_url)
    toggleState("scoreBtn", nchar(selectedDeployment$scoring_url) > 0 && nchar(serverVariables$token) > 0)
    
    
  })
  
  # Handle model deployment scoring button
  observeEvent(input$scoreBtn, {
    shinyjs::disable("scoreBtn")
    selectedDeployment <- serverVariables$deployments[[input$deploymentSelector]]
    
  #  payload = list(
  #    values = '2018-09-30',
  #    cust_id = sessionVars$selectedClientId
  #  )
    
    response <- scoreModelDeployment(selectedDeployment$scoring_url, sessionVars$pipelineInput, serverVariables$token)
    
    
    if(length(response$error) > 0) {
      output$scoringError <- renderText(toString(response$error))
    }
    else if(length(response$predictions) > 0) {
      shinyjs::hide(id = "scoreBtnSection")
      shinyjs::show(id = "scoringResponse")
      
      
      
      for(event_type in names(response$predictions[[1]]$values)) {

        #event_result <-  response$predictions[[1]]$values[[event_type]]$predictions[[1]]
     #   has_explain <- length(event_result$explain_plot_html) > 0
        
    #    explain_panel1 <- p()
    #    explain_panel2 <- div()
    #    if(has_explain) {
    #      explain_panel1 <- p(
    #                           tableOutput(paste0("explain-table-",event_type))
    #                         )
    #      explain_panel2 <- div(
    #        p(
    #          strong("Explanation Plot: ")
    #        ),
    #        HTML(event_result$explain_plot_html)
    #      )
    #   }
        
        insertUI(
          selector = "#scoringResponse",
          where = "beforeEnd",
          immediate = TRUE,

          
          ui = panel(
            div(
              id = paste0(sessionVars$selectedClientId,"-",event_type),
              
              h3(paste("Life Event:", event_type)),
              fluidRow(
                column(6,
                      plotOutput(paste0("probPlot-",event_type), width = "600px", height = "400px")
                ),
                column(6,
                     #explain_panel1
                )
              ),
             #explain_panel2
            ))
        )
        
  #      if(has_explain) {
  #         # send responseInserted message
  #        session$sendCustomMessage('responseInserted',
  #                                  list(
  #                                    id=event_result$explain_plot_elem_id,
  #                                    data=fromJSON(event_result$explain_plot_data))
  #                                  )
  #      }
   }
  #    
     lapply(names(response$predictions[[1]]$values), function(event_type) {
       event_result <-  response$predictions[[1]]$values[[event_type]]$predictions[[1]]
 
        
        # generate probability pie
        probDF <- data.frame(t(data.frame(event_result$values[[1]][[2]])))
        colnames(probDF) <- "Probability"
        row.names(probDF) <- c("FALSE", "TRUE")
        probDF <- tibble::rownames_to_column(probDF, "Prediction")
        probDF <- probDF %>%
          mutate(percentage = paste0(round(100 * Probability, 1), "%")) %>%
          mutate(hover_text = paste0(Prediction, ": ", percentage))
        
        probPlot <- ggplot(probDF, aes(y = Probability, fill = Prediction)) +
          geom_bar(
            aes(x = 1, tooltip = hover_text),
            width = 0.4,
            stat = "identity",
            show.legend = TRUE
          ) + 
          annotate("text", x = 0, y = 0, size = 12,
                   label = probDF[["percentage"]][probDF[["Prediction"]] == "TRUE"]
                  ) +
          coord_polar(theta = "y") +
          theme_void() +
          theme(legend.title=element_text(size=22),
                legend.text=element_text(size=16)) +
          guides(fill = guide_legend(reverse=TRUE))
        output[[paste0("probPlot-",event_type)]] <- renderPlot(probPlot, width="auto", height="auto")
     })
    } else {
      output$scoringError <- renderText(response)
    }
    shinyjs::enable("scoreBtn")
  })
}

